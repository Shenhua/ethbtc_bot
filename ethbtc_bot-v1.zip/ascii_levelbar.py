RESET="\x1b[0m"; GREEN="\x1b[32m"; YELLOW="\x1b[33m"; CYAN="\x1b[36m"
import sys
from typing import List, Optional, Tuple

def _use_color()->bool:
    try: return sys.stdout.isatty()
    except Exception: return False

def clamp(x, lo, hi): return max(lo, min(hi, x))

def _spark(values: List[float], lo: float, hi: float) -> str:
    chars="▁▂▃▄▅▆▇█"; span = hi-lo if hi>lo else 1.0; out=[]
    for v in values[-40:]:
        lvl=int(round(((v-lo)/span)*(len(chars)-1))); lvl=max(0,min(len(chars)-1,lvl)); out.append(chars[lvl])
    return "".join(out)


def draw_bar(current: float, target: float, *, min_val: float, max_val: float, width: int = 40,
             label: str = "", units: str = "", ascii_only: bool = False) -> str:
    """
    Returns a single-line bar like:
    [██████████▊│──────────────]  0.0180 / 0.0200 (Δ=+0.0020)
    Uses sub-cell Unicode blocks for higher resolution when ascii_only=False.
    """
    if max_val <= min_val:
        max_val = min_val + 1e-9
    span = max_val - min_val
    c = clamp(current, min_val, max_val)
    t = clamp(target,  min_val, max_val)

    w = max(3, int(width))

    if ascii_only:
        fill = "#"; empty = "-"; marker = "|"
        # Simple cell-based bar
        prog = (c - min_val) / span
        c_pos = int(round(prog * (w - 1)))
        t_pos = int(round(((t - min_val) / span) * (w - 1)))
        cells = [empty] * w
        for i in range(0, c_pos + 1):
            cells[i] = fill
        cells[t_pos] = marker
        bar = "[" + "".join(cells) + "]"
    else:
        # Hi-res bar with 1/8th block granularity
        partials = ["", "▏","▎","▍","▌","▋","▊","▉"]
        full = "█"; empty = "─"; marker = "│"
        prog = (c - min_val) / span
        tprog = (t - min_val) / span
        # compute exact columns
        exact_cols = prog * w
        full_cols = int(exact_cols)  # full blocks
        frac = exact_cols - full_cols  # 0..1
        partial_idx = int(round(frac * 8))  # 0..8
        if partial_idx == 8:
            full_cols += 1
            partial_idx = 0
        # target marker column (discrete cell)
        t_pos = int(round(tprog * (w - 1)))

        cells = [empty] * w
        for i in range(min(full_cols, w)):
            cells[i] = full
        if partial_idx > 0 and full_cols < w:
            cells[full_cols] = partials[partial_idx]
        # Ensure marker visibility
        if 0 <= t_pos < w:
            cells[t_pos] = marker
        bar = "[" + "".join(cells) + "]"

    delta = target - current
    status = f"{current:.4f}{units} / {target:.4f}{units} (Δ={delta:+.4f}{units})"
    if label:
        status = f"{label}: " + status
    return f"{bar}  {status}"


def live_block(current: float, target: float, *, min_val: float, max_val: float, width: int=40,
               history: Optional[List[float]]=None, label: str="", units: str="", ascii_only: bool=False)->str:
    bar=draw_bar(current,target,min_val=min_val,max_val=max_val,width=width,label=label,units=units,ascii_only=ascii_only)
    spark = ""
    if history is not None:
        spark=_spark(history,min_val,max_val)
        if _use_color(): spark=CYAN+spark+RESET
        spark="spark: "+spark
    return bar+("\n"+spark if spark else "")

def trigger_check(current: float, target: float) -> Tuple[bool,str]:
    return (current>=target, ("TRIGGER" if current>=target else f"{target-current:.4f} remaining"))
