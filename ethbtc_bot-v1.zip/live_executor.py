#!/usr/bin/env python3
"""
live_executor.py — run the ETH/BTC accumulation strategy on Binance Spot
- Uses the SAME JSON parameter file as your optimizer/backtester
- Can run in DRY-RUN (no orders), TESTNET, or LIVE
- Idempotent per 15-minute bar with persistent state
"""

import os, sys, json, time, math, argparse, logging, csv
from pathlib import Path
from dataclasses import asdict
from datetime import datetime, timezone, timedelta
import random  # ADD: for jitter in backoff
import pandas as pd
import numpy as np

from ascii_levelbar import draw_bar
# Exchange connector (official)
from binance.spot import Spot
from binance.error import ServerError  # ADD: to detect retriable server errors

# Import your strategy module (provided by you)
from ethbtc_accum_bot import StratParams, FeeParams, EthBtcStrategy

STATE_DEFAULT = "state.json"
FIFTEEN_MIN = 15
# Optional .env loader
try:
    from dotenv import load_dotenv  # pip install python-dotenv
except Exception:
    load_dotenv = None

def _preload_env():
    # Load .env BEFORE argparse reads defaults from os.environ
    import os
    dotenv_path = os.getenv("DOTENV_PATH", ".env")
    loaded = False
    if load_dotenv is not None and os.path.exists(dotenv_path):
        try:
            load_dotenv(dotenv_path)
            loaded = True
        except Exception:
            loaded = False
    if not loaded and os.path.exists(dotenv_path):
        # fallback parser for KEY=VALUE lines
        with open(dotenv_path, "r", encoding="utf-8") as f:
            for line in f:
                line=line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k,v = line.split("=",1)
                if k and (k not in os.environ):
                    os.environ[k.strip()] = v.strip()
        loaded = True
    return dotenv_path, loaded

from typing import Optional, Tuple

def _interval_to_minutes(s: str) -> int:
    s = s.strip().lower()
    units = {"m": 1, "h": 60, "d": 1440, "w": 10080}
    try:
        return int(s[:-1]) * units[s[-1]]
    except Exception as e:
        raise ValueError(f"Unsupported interval string: {s}") from e


# --- Begin: resilient API helper ---
def api_retry(call, *, args=None, kwargs=None, retries=6, base_delay=1.0, max_delay=20.0,
              retriable_statuses=(429, 500, 502, 503, 504), logger=logging.getLogger(__name__)):
    """
    Retry wrapper for Binance client calls. Uses exponential backoff + jitter.
    - call: a callable (e.g., client.exchange_info)
    - args/kwargs: arguments to pass to the callable
    - retries: total attempts (including first try)
    """
    if logger is None:
        logger = logging.getLogger(__name__)

    for attempt in range(1, retries + 1):
        try:
            return call(*(args or ()), **(kwargs or {}))
        except ServerError as e:
            code = getattr(e, "status_code", None)
            if code in retriable_statuses:
                delay = min(max_delay, base_delay * (2 ** (attempt - 1)))
                delay *= (1.3 + 0.6 * random.random())  # jitter ~[1.3,1.3]x
                logger.warning("Binance %s on %s (attempt %d/%d). Sleeping %.1fs",
                               code, getattr(call, "__name__", str(call)), attempt, retries, delay)
                time.sleep(delay)
                continue
            # Non-retriable server error → re-raise
            raise
        except Exception as e:
            # Network hiccup, DNS, timeouts, etc. → retry
            delay = min(max_delay, base_delay * (2 ** (attempt - 1)))
            delay *= (1.3 + 0.6 * random.random())
            logger.warning("Transient error %r on %s (attempt %d/%d). Sleeping %.1fs",
                           e, getattr(call, "__name__", str(call)), attempt, retries, delay)
            time.sleep(delay)
    raise RuntimeError(f"api_retry: exhausted retries for {getattr(call, '__name__', call)}")
# --- End: resilient API helper ---
# 
#     
def compute_gate_ok(
    klines,
    interval_str: str,
    gate_window_days: float,
    gate_roc_threshold: Optional[float],
) -> Tuple[Optional[bool], str]:
    """
    Returns (gate_ok, reason)
    gate_ok: True (allowed), False (blocked), None (not enough data)
    """
    # Gate disabled?
    if not gate_window_days or gate_roc_threshold is None:
        return True, "gate disabled"

    # How many bars we need for the ROC window
    bar_minutes = _interval_to_minutes(interval_str)
    needed_bars = int(gate_window_days * 1440 // bar_minutes)

    if len(klines) < needed_bars + 1:
        missing = (needed_bars + 1) - len(klines)
        return None, f"need {missing} more bars for {gate_window_days}d gate"

    # Binance kline close is at index 4 (string); convert to float
    start_close = float(klines[-(needed_bars + 1)][4])
    end_close = float(klines[-1][4])
    roc = (end_close / start_close) - 1.0  # simple n-bar ROC

    ok = abs(roc) >= float(gate_roc_threshold)  # adjust if you want directional logic
    return ok, f"roc={roc:.5f} vs thr={gate_roc_threshold:.5f}"


class TradeRecorder:
    def __init__(self, path: str):
        self.path = path
        self._ensure_header()

    def _ensure_header(self):
        if not self.path:
            return
        p = Path(self.path)
        if p.exists() and p.stat().st_size > 0:
            return
        headers = ["timestamp","symbol","side","order_type","status","executed_qty","avg_price","quote_qty","fills_count","maker_like"]
        with open(self.path, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=headers)
            w.writeheader()

    def log(self, **row):
        if not self.path:
            return
        with open(self.path, "a", newline="", encoding="utf-8") as f:
            headers = ["timestamp","symbol","side","order_type","status","executed_qty","avg_price","quote_qty","fills_count","maker_like"]
            w = csv.DictWriter(f, fieldnames=headers)
            # coerce
            for k in headers:
                if k not in row: row[k] = None
            w.writerow(row)

def parse_fills_from_order(order: dict):
    # Works for MARKET new_order response (has 'fills') or for get_order (has executedQty/cummulativeQuoteQty)
    fills = order.get("fills") or []
    executed_qty = None
    quote_qty = None
    avg_price = None
    if fills:
        # sum fills
        tq = 0.0; qq = 0.0
        for f in fills:
            q = float(f.get("qty", f.get("qty", 0)) or 0)
            p = float(f.get("price", f.get("price", 0)) or 0)
            tq += q
            qq += q * p
        executed_qty = tq
        avg_price = (qq / tq) if tq > 0 else None
        quote_qty = qq
    else:
        try:
            executed_qty = float(order.get("executedQty", 0) or 0)
        except Exception:
            executed_qty = 0.0
        try:
            cq = order.get("cummulativeQuoteQty", order.get("cummulativeQuoteQty", 0) or 0)
            quote_qty = float(cq or 0)
        except Exception:
            quote_qty = None
        if executed_qty and quote_qty is not None and executed_qty > 0:
            avg_price = quote_qty / executed_qty
    return executed_qty or 0.0, avg_price, quote_qty, len(fills)

def utcnow():
    return datetime.now(timezone.utc)

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def coalesce(*args):
    for a in args:
        if a is not None:
            return a
    return None

def mk_logger(verbosity:int):
    lvl = logging.INFO if verbosity==0 else (logging.DEBUG if verbosity>0 else logging.WARNING)
    logging.basicConfig(level=lvl, format="%(asctime)s %(levelname)s %(message)s")

    # Quiet noisy third-party loggers even when running with -v
    for _name in (
        "urllib3",
        "urllib3.connectionpool",
        "requests",
        "binance",
        "websocket",
        "websockets",
        "aiohttp",
    ):
        _lg = logging.getLogger(_name)
        _lg.setLevel(logging.WARNING)
        _lg.propagate = False
    return logging.getLogger("executor")

def load_params(params_path:str):
    raw = load_json(params_path)
    cfg = raw.get("strategy", raw)  # support flat or {"strategy":{...}}

    def _coerce(val, default, cast):
        if val is None or (isinstance(val, str) and val.strip()==""):
            val = default
        try:
            return cast(val)
        except Exception:
            return cast(default)

    # floats
    f  = lambda k, d: _coerce(cfg.get(k, d), d, float)
    # ints
    i  = lambda k, d: _coerce(cfg.get(k, d), d, int)
    # strings
    s  = lambda k, d: cfg.get(k, d) if cfg.get(k, d) is not None else d
    # bools
    def b(k, d=True):
        v = cfg.get(k, d)
        if isinstance(v, bool): return v
        if v is None: return d
        if isinstance(v, str): return v.strip().lower() in ("1","true","yes","y","on")
        return bool(v)

    sp = StratParams(
        trend_kind             = s("trend_kind", "roc"),
        trend_lookback         = i("trend_lookback", 120),
        flip_band_entry        = f("flip_band_entry", 0.03),
        flip_band_exit         = f("flip_band_exit", 0.015),
        vol_window             = i("vol_window", 45),
        target_vol             = f("target_vol", 0.30),
        min_mult               = f("min_mult", 0.5),
        max_mult               = f("max_mult", 1.5),
        cooldown_minutes       = i("cooldown_minutes", 240),
        step_allocation        = f("step_allocation", 0.33),
        max_position           = f("max_position", 0.8),
        rebalance_threshold_w  = f("rebalance_threshold_w", 0.03),
        gate_window_days       = i("gate_window_days", 30),
        gate_roc_threshold     = f("gate_roc_threshold", 0.02),
        min_trade_btc          = f("min_trade_btc", 0.0002),  # explicit min if present; dynamic logic will override later
    )

    fees = raw.get("fees", raw.get("execution", {}))  # tolerate missing/alt nesting
    if fees is None: fees = {}

    def ff(k, d):  # float in fees
        v = fees.get(k, d)
        return d if v is None else float(v)

    def bb(k, d=True):
        v = fees.get(k, d)
        if isinstance(v, bool): return v
        if v is None: return d
        if isinstance(v, str): return v.strip().lower() in ("1","true","yes","y","on")
        return bool(v)

    fp = FeeParams(
        maker_fee      = ff("maker_fee", 0.0002),
        taker_fee      = ff("taker_fee", 0.0004),
        slippage_bps   = ff("slippage_bps", 1.0),
        bnb_discount   = ff("bnb_discount", 0.25),
        pay_fees_in_bnb= bb("pay_fees_in_bnb", True),
    )

    # Execution config for dynamic min trade notional
    exec_cfg = {
        "explicit_min": (None if cfg.get("min_trade_btc", None) is None else float(cfg.get("min_trade_btc"))),
        "min_trade_frac": float(cfg.get("min_trade_frac", 0.0015)),
        "min_trade_floor_btc": float(cfg.get("min_trade_floor_btc", 0.0002)),
        "min_trade_cap_btc": float(cfg.get("min_trade_cap_btc", 0.0)),  # 0 = no cap
    }
    return sp, fp, exec_cfg



def save_state(path:str, state:dict):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, default=str)
    os.replace(tmp, path)

def load_state(path:str):
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def symbol_filters(client: Spot, symbol: str):
    info = api_retry(client.exchange_info, kwargs={"symbol": symbol}, logger=logging.getLogger(__name__))
    sym = info["symbols"][0]
    filters = {f["filterType"]: f for f in sym["filters"]}
    lot_step = float(filters["LOT_SIZE"]["stepSize"])
    lot_min  = float(filters["LOT_SIZE"]["minQty"])
    px_tick  = float(filters["PRICE_FILTER"]["tickSize"])
    min_notional = None
    if "MIN_NOTIONAL" in filters:
        min_notional = float(filters["MIN_NOTIONAL"].get("minNotional", 0))
    return lot_step, lot_min, px_tick, min_notional

def round_step(x: float, step: float):
    return math.floor(x/step) * step

def round_price(p: float, tick: float):
    return round_step(p, tick)

def build_client(mode: str, base_url_env: str | None):
    # Default to testnet base if mode=testnet and no explicit base passed
    if mode == "testnet":
        base = base_url_env or "https://testnet.binance.vision"
    else:
        base = base_url_env or None  # None = production default

    api_key = os.environ["BINANCE_KEY"]
    api_secret = os.environ["BINANCE_SECRET"]

    if base:
        return Spot(api_key=api_key, api_secret=api_secret, base_url=base)
    return Spot(api_key=api_key, api_secret=api_secret)

def fetch_klines(client: Spot, symbol: str, limit:int=500):
    # 15m klines
    ks = client.klines(symbol, "15m", limit=limit)
    df = pd.DataFrame(ks, columns=[
        "open_time","o","h","l","c","v","close_time","q","n","tbbav","tbqav","ig"
    ])
    df["close_time"] = pd.to_datetime(df["close_time"], unit="ms", utc=True)
    df["c"] = df["c"].astype(float)
    out = df[["close_time","c"]].rename(columns={"c":"close"})
    out = out.set_index("close_time").sort_index()
    return out

def fetch_balances(client: Spot):
    acct = client.account()
    bals = {b["asset"]: float(b["free"])+float(b["locked"]) for b in acct["balances"]}
    return bals

def compute_weights(btc: float, eth: float, price: float):
    W = btc + eth*price
    cur_w = 0.0 if W <= 0 else (eth*price)/W
    return W, cur_w

def last_closed_bar(index: pd.DatetimeIndex):
    # This is just the last index from the klines call (already closed)
    return index[-1]

def newest_bar_is_new(state:dict, last_bar_close: datetime):
    prev = state.get("last_bar_close")
    if not prev:
        return True
    try:
        prev_dt = pd.to_datetime(prev, utc=True)
    except Exception:
        return True
    return last_bar_close > prev_dt
# Compute gate based on a price Series (no raw klines required)
def compute_gate_ok_from_prices(close_series, window_days: int, roc_thresh: float, interval_minutes: int = 15) -> bool:
    """
    Returns True if the rate-of-change over the window_days meets/exceeds roc_thresh.
    close_series: pandas Series of closes (ascending index)
    window_days: number of days to look back
    roc_thresh: e.g. 0.02 for +2%
    interval_minutes: candle interval (default 15 for 15m)
    """
    try:
        import pandas as pd  # local import to keep top-level deps minimal
        if close_series is None or len(close_series) == 0:
            return True  # nothing to gate on -> allow

        bars_per_day = max(1, (24 * 60) // interval_minutes)
        lookback_bars = max(2, window_days * bars_per_day)

        window = close_series.iloc[-lookback_bars:] if len(close_series) >= lookback_bars else close_series
        first = float(window.iloc[0])
        last = float(window.iloc[-1])
        if first <= 0:
            return True  # avoid divide-by-zero; default open gate

        roc = (last - first) / first
        return roc >= roc_thresh
    except Exception:
        # On any unexpected issue, fail open so the bot doesn't freeze trading
        return True
    
def main():
    dotenv_path, env_loaded = _preload_env()
    
    ap = argparse.ArgumentParser(description="Live execution for ETHBTC accumulation strategy")
    ap.add_argument("--params", required=True, help="Path to strategy JSON (same file as backtest/optimizer)")
    ap.add_argument("--symbol", default=os.getenv("SYMBOL", "ETHBTC"))
    ap.add_argument("--mode", choices=["dry","testnet","live"], default=os.getenv("MODE","dry"))
    ap.add_argument("--poll-sec", type=int, default=10, help="Polling interval seconds")
    ap.add_argument("--klines-limit", type=int, default=600, help="How many 15m klines to pull")
    ap.add_argument("--state", default=os.getenv("STATE_FILE", STATE_DEFAULT))
    ap.add_argument("--ttl-sec", type=int, default=90, help="TTL for post-only orders before cancel")
    ap.add_argument("--trades-csv", default=os.getenv("TRADES_CSV", "trades_log.csv"))
    ap.add_argument("--taker-fallback", action="store_true", help="After TTL, send a taker order for remaining qty")
    ap.add_argument("-v", "--verbose", action="count", default=0)
    args = ap.parse_args()

    log = mk_logger(args.verbose)
    last_hb_ts = 0.0
    last_hb_payload = None
    log.info("Env file: %s (loaded=%s); MODE=%s",
         os.getenv("DOTENV_PATH", ".env"), str(env_loaded), os.getenv("MODE"))
    # Build client
    base_url = os.getenv("BINANCE_BASE_URL")
    if args.mode in ("testnet","live"):
        if not os.getenv("BINANCE_KEY") or not os.getenv("BINANCE_SECRET"):
            log.error("BINANCE_KEY / BINANCE_SECRET must be set for testnet/live")
            sys.exit(2)
        client = build_client(args.mode, base_url)
        log.info("Mode=%s base_url=%s", args.mode, getattr(client, "_base_url", None))
    else:
        client = None
        log.info("Mode=dry (no orders)")

    # Load params
    sp, fp, exec_cfg = load_params(args.params)
    log.info("Loaded params: %s", asdict(sp))
    log.info("Dynamic min notional config: %s", exec_cfg)

    trade_rec = TradeRecorder(args.trades_csv)

    state = load_state(args.state)

    # Preload filters
    lot_step = lot_min = px_tick = min_notional = None
    if args.mode in ("testnet","live"):
        while True:
            try:
                lot_step, lot_min, px_tick, min_notional = symbol_filters(client, args.symbol)
                break
            except Exception as e:
                logging.warning("Could not fetch exchangeInfo for %s (%s). Will retry in 10s and keep running.",
                        args.symbol, e)
                time.sleep(10)
        log.info("Filters: lot_step=%s lot_min=%s px_tick=%s min_notional=%s",
                 lot_step, lot_min, px_tick, min_notional)


    # Startup banner
    try:
        if client:
            srv_ms = client.time().get("serverTime")
            if srv_ms:
                srv = pd.to_datetime(srv_ms, unit="ms", utc=True)
                drift = abs((srv - pd.Timestamp.utcnow()).total_seconds())
                log.info("ServerTime=%s (drift≈%.2fs)", srv.isoformat(), drift)
    except Exception as e:
        log.warning("Failed server time check: %s", e)
    # Startup banner
    try:
        if client:
            srv_ms = client.time().get("serverTime")
            if srv_ms:
                srv = pd.to_datetime(srv_ms, unit="ms", utc=True)
                drift = abs((srv - pd.Timestamp.utcnow()).total_seconds())
                log.info("ServerTime=%s (drift≈%.2fs)", srv.isoformat(), drift)
    except Exception as e:
        log.warning("Failed server time check: %s", e)

    # Main loop
    while True:
        # Timed heartbeat: once every args.ttl_sec using the last known payload
        _now = time.monotonic()
        if _now - last_hb_ts >= args.ttl_sec and last_hb_payload is not None:
            hb_bar, hb_px, hb_W, hb_cur, hb_tgt, hb_gate = last_hb_payload
            log.info("[HB] bar=%s px=%.8f W=%.8f cur_w=%.4f tgt_w=%.4f gate=%s",
                    hb_bar, hb_px, hb_W, hb_cur, hb_tgt, str(hb_gate))
            last_hb_ts = _now
        # 1) Data
        if args.mode == "dry":
            # In dry mode, we still want latest klines to compute, but no orders.
            # If you don't have keys, you can skip and just sleep.
            if base_url:
                # if user provided testnet base without keys, skip pulling
                time.sleep(args.poll_sec); continue
            else:
                log.warning("Dry mode without data source: sleeping...")
                time.sleep(args.poll_sec); continue

        df = fetch_klines(client, args.symbol, limit=args.klines_limit)
        last_bar = last_closed_bar(df.index)

        from datetime import datetime, timezone, timedelta

        if not newest_bar_is_new(state, last_bar):
            next_close = last_bar + timedelta(minutes=15)
            now = datetime.now(timezone.utc)
            eta = max(0.0, (next_close - now).total_seconds())

            WARMUP = 3.0  # seconds before close to start tight polling
            if eta > WARMUP:
                # Sleep straight to the warmup window—no heartbeat logs here
                time.sleep(eta - WARMUP)
                continue

            # Tight polling in the last few seconds to catch the close quickly
            time.sleep(0.25)
            continue

        price = float(df["close"].iloc[-1])

        # 2) Balances & current weight
        bals = fetch_balances(client)
        btc = float(bals.get("BTC", 0.0))
        eth = float(bals.get("ETH", 0.0))
        W, cur_w = compute_weights(btc, eth, price)

        log.debug("Wealth W=%.8f BTC (btc=%.8f, eth=%.8f @ %.8f)", W, btc, eth, price)

        # 3) Compute target weight with your strategy (same logic as backtest)
        strat = EthBtcStrategy(sp)
        positions = strat.generate_positions(df["close"])
        cols = [c.lower() for c in positions.columns]
        # Pick the target weight column (case-insensitive)
        lower_map = {c.lower(): c for c in positions.columns}
        target_col = None
        for cand in ("target_w", "w", "target_weight"):
            if cand in lower_map:
                target_col = lower_map[cand]
                break

        if not target_col:
            # Fallback: if no target weight, skip
            logging.error(
                "No target weight column found in strategy output. Columns: %s",
                list(positions.columns),
            )
            state["last_bar_close"] = last_bar.isoformat()
            save_state(args.state, state)
            time.sleep(args.poll_sec)
            continue

        target_w = float(positions.iloc[-1][target_col])

        # Gate (optional) — prefer the strategy's gate flag if present,
        # otherwise compute a ROC-based gate from prices.
        if "gate" in cols:
            # Use original column name via lower_map to be case-safe
            gate_ok = bool(positions.iloc[-1][lower_map["gate"]])
            gate_reason = "strategy gate=False" if not gate_ok else "n/a"
        else:
            gate_ok = compute_gate_ok_from_prices(
                df["close"],
                window_days=sp.gate_window_days,
                roc_thresh=sp.gate_roc_threshold,
                interval_minutes=15,  # 15m candles
            )
            gate_reason = (
                f"ROC<{sp.gate_roc_threshold:.2%} over {sp.gate_window_days}d"
                if not gate_ok else
                "n/a"
            )

        # Gate (optional) — if strategy provides a gate flag, honor it
        # We also support a computed ROC-based gate using the fetched 15m closes.
        gate_ok = True
        gate_reason = "no_gate_column"
        if "gate" in cols:
            gate_ok = bool(positions.iloc[-1]["gate"])
            gate_reason = "strategy_gate_true" if gate_ok else "strategy_gate_false"
        else:
            # Use the helper that works with price SERIES (no klines object needed)
            # fetch_klines() in this script uses 15m candles, so interval_minutes=15
            gate_ok = compute_gate_ok_from_prices(
                df["close"],
                window_days=sp.gate_window_days,
                roc_thresh=sp.gate_roc_threshold,
                interval_minutes=15,  # 15m candles
            )
            gate_reason = "roc_ok" if gate_ok else f"roc_below_{sp.gate_roc_threshold:.3f}"
        # Save payload for timed heartbeats
        last_hb_payload = (
            last_bar.isoformat(),
            price,
            W,
            cur_w,
            target_w,
            bool(gate_ok),
        )
        # Heartbeat line (INFO): bar, price, wealth, weights, gate
        log.info("[HB] bar=%s px=%.8f W=%.8f cur_w=%.4f tgt_w=%.4f gate=%s",
                 last_bar.isoformat(), price, W, cur_w, target_w, str(gate_ok))

        if not gate_ok:
            # BAR: ROC (close) vs gate — print on every closed bar
            try:
                if sp.gate_roc_threshold is not None and sp.gate_window_days:
                    bars_per_day  = max(1, (24 * 60) // 15)  # 15m bars/day
                    want          = int(sp.gate_window_days * bars_per_day)
                    have          = len(df['close']) if 'close' in df else 0
                    use           = max(1, min(want, max(1, have - 1)))  # fall back if we don't have full window locally
                    if have >= 2:
                        start_close = float(df['close'].iloc[-(use + 1)])
                        end_close   = float(df['close'].iloc[-1])
                        roc_close   = abs((end_close / start_close) - 1.0)
                        log.info(
                            "%s",
                            draw_bar(
                                roc_close, abs(sp.gate_roc_threshold),
                                min_val=0.0,
                                max_val=max(abs(sp.gate_roc_threshold) * 2.0, 0.05),
                                width=50, label="ROC (close) vs gate", ascii_only=False
                            )
                        )
            except Exception as _e:
                log.debug("ROC bar skipped: %r", _e)
            log.info("SKIP gate closed at bar=%s (%s)", last_bar.isoformat(), gate_reason)
            state["last_bar_close"] = last_bar.isoformat()
            save_state(args.state, state)
            time.sleep(args.poll_sec); continue

        # Smooth with step_allocation like in backtest (one step toward target)
        new_w = cur_w + sp.step_allocation * (target_w - cur_w)
        new_w = max(-sp.max_position, min(sp.max_position, new_w))
        # BAR: Δw vs threshold — prints on bar close, whether or not we act
        try:
            cur_gap = abs(new_w - cur_w)
            log.info(
                "%s",
                draw_bar(
                    cur_gap, sp.rebalance_threshold_w,
                    min_val=0.0,
                    max_val=max(sp.rebalance_threshold_w * 3.0, 0.10),
                    width=50, label="Δw vs threshold", ascii_only=False
                )
            )
        except Exception as _e:
            log.debug("Δw bar skipped: %r", _e)
        # Deadband / rebalance threshold
        if abs(new_w - cur_w) < sp.rebalance_threshold_w:
            log.info(
                "SKIP deadband: cur_w=%.4f target_w=%.4f new_w=%.4f (threshold=%.4f)",
                cur_w, target_w, new_w, sp.rebalance_threshold_w
            )

            state["last_bar_close"] = last_bar.isoformat()
            save_state(args.state, state)
            time.sleep(args.poll_sec); continue

        # Cooldown
        last_trade_time = pd.to_datetime(state.get("last_trade_time"), utc=True) if state.get("last_trade_time") else None
        if last_trade_time is not None:
            mins = (last_bar - last_trade_time).total_seconds()/60
            if mins < sp.cooldown_minutes:
                log.info("SKIP cooldown: elapsed=%.1f min < %d min", mins, sp.cooldown_minutes)
                state["last_bar_close"] = last_bar.isoformat()
                save_state(args.state, state)
                time.sleep(args.poll_sec); continue

        # Gate check
        if not gate_ok:
            log.info("SKIP gate closed at bar=%s", last_bar.isoformat())
            state["last_bar_close"] = last_bar.isoformat()
            save_state(args.state, state)
            time.sleep(args.poll_sec); continue

        # 4) Compute trade size (ETH)
        eth_target = (W * new_w) / price if W > 0 else 0.0
        d_eth = eth_target - eth
        side = "BUY" if d_eth > 0 else "SELL"
        qty = abs(d_eth)

        # Notional threshold check
        # --- Dynamic minimum notional ---
        explicit_min = exec_cfg.get("explicit_min")
        if explicit_min is not None and explicit_min > 0:
            effective_min = explicit_min
        else:
            frac = exec_cfg.get("min_trade_frac", 0.0015)
            floor_btc = exec_cfg.get("min_trade_floor_btc", 0.0002)
            cap_btc = exec_cfg.get("min_trade_cap_btc", 0.0)
            dynamic_min = max(floor_btc, frac * W)  # grow with wealth
            if cap_btc and cap_btc > 0:
                dynamic_min = min(dynamic_min, cap_btc)
            effective_min = dynamic_min

        # Also honor Binance MIN_NOTIONAL
        effective_min_exch = max(effective_min, (min_notional or 0.0))
        if qty * price < effective_min_exch:
            log.info("SKIP min notional: notional=%.8f < required=%.8f (effective=%.8f, exch_min=%s)", qty*price, effective_min_exch, effective_min, str(min_notional))
            state["last_bar_close"] = last_bar.isoformat()
            save_state(args.state, state)
            time.sleep(args.poll_sec); continue

        # Round to filters
        qty_r = round_step(qty, lot_step)
        price_r = round_price(price, px_tick)

        if qty_r <= 0 or (min_notional and qty_r*price_r < min_notional):
            log.info("SKIP after rounding: qty_r=%.10f price_r=%.10f (min_notional=%s)", qty_r, price_r, str(min_notional))
            state["last_bar_close"] = last_bar.isoformat()
            save_state(args.state, state)
            time.sleep(args.poll_sec); continue

        log.info("PLAN %s %s @ %.8f (cur_w=%.4f -> new_w=%.4f; notional=%.8f; effective_min≈%.8f)", side, f"{qty_r:.10f}", price_r, cur_w, new_w, qty_r*price_r, effective_min) 

        if args.mode == "dry":
            # record but do not send
            state["last_bar_close"] = last_bar.isoformat()
            state["last_trade_time"] = last_bar.isoformat()
            save_state(args.state, state)
            time.sleep(args.poll_sec); continue

        # 5) Place post-only order (LIMIT_MAKER)
        try:
            resp = client.new_order(symbol=args.symbol, side=side, type="LIMIT_MAKER",
                                    quantity=f"{qty_r:.8f}", price=f"{price_r:.8f}", newOrderRespType="FULL")
            order_id = resp["orderId"]
            log.info("Placed LIMIT_MAKER order id=%s", order_id)
            state["open_order_id"] = order_id
            state["last_bar_close"] = last_bar.isoformat()
            save_state(args.state, state)
        except Exception as e:
            log.error("Order rejected: %s", e)
            # Mark bar as processed to avoid tight loop
            state["last_bar_close"] = last_bar.isoformat()
            save_state(args.state, state)
            time.sleep(args.poll_sec); continue

        # 6) TTL then check status, cancel if needed, taker fallback
        ttl = int(args.ttl_sec)
        time.sleep(ttl)

        status = "UNKNOWN"
        executed_qty = 0.0
        avg_fill_price = None
        quote_qty = None
        fills_count = 0

        try:
            od = client.get_order(symbol=args.symbol, orderId=state.get("open_order_id"))
            status = od.get("status", status)
            executed_qty, avg_fill_price, quote_qty, fills_count = parse_fills_from_order(od)
            log.info("ORDER STATUS id=%s status=%s executed=%.10f avg_px=%s", state.get("open_order_id"), status, executed_qty, (f"{avg_fill_price:.8f}" if avg_fill_price else "n/a"))
        except Exception as e:
            log.warning("get_order failed (assuming possibly filled): %s", e)

        # If still working or partial, cancel
        if status in ("NEW","PARTIALLY_FILLED"):
            try:
                client.cancel_order(symbol=args.symbol, orderId=state.get("open_order_id"))
                log.info("CANCELLED open order id=%s", state.get("open_order_id"))
            except Exception as e:
                log.info("Cancel not needed or failed (maybe already fully filled): %s", e)

        # Record maker-like fills if any
        if executed_qty and executed_qty > 0:
            trade_rec.log(timestamp=last_bar.isoformat(), symbol=args.symbol, side=side,
                          order_type="LIMIT_MAKER", status=status, executed_qty=f"{executed_qty:.10f}",
                          avg_price=(f"{avg_fill_price:.8f}" if avg_fill_price else None),
                          quote_qty=(f"{(quote_qty or (executed_qty*price_r)):.8f}"),
                          fills_count=fills_count, maker_like=1)
            # update counters in state
            state["trade_count"] = int(state.get("trade_count", 0)) + 1
            state["cum_turnover_btc"] = float(state.get("cum_turnover_btc", 0.0)) + (executed_qty * (avg_fill_price or price_r))
            save_state(args.state, state)

        # If not filled and taker fallback is enabled, send MARKET for the remaining qty
        remaining = max(0.0, qty_r - (executed_qty or 0.0))
        if remaining > 0 and args.taker_fallback:
            try:
                resp2 = client.new_order(symbol=args.symbol, side=side, type="MARKET",
                                         quantity=f"{remaining:.8f}", newOrderRespType="FULL")
                ex2, px2, qq2, nfills2 = parse_fills_from_order(resp2)
                log.info("FALLBACK MARKET executed=%.10f avg_px=%s fills=%s", ex2, (f"{px2:.8f}" if px2 else "n/a"), nfills2)
                trade_rec.log(timestamp=last_bar.isoformat(), symbol=args.symbol, side=side,
                              order_type="MARKET", status="FILLED", executed_qty=f"{ex2:.10f}",
                              avg_price=(f"{px2:.8f}" if px2 else None),
                              quote_qty=(f"{(qq2 or (ex2*price)):.8f}"),
                              fills_count=nfills2, maker_like=0)
                state["trade_count"] = int(state.get("trade_count", 0)) + 1
                state["cum_turnover_btc"] = float(state.get("cum_turnover_btc", 0.0)) + (ex2 * (px2 or price))
                save_state(args.state, state)
            except Exception as e2:
                log.error("Taker fallback failed: %s", e2)

        # Clear open order id and stamp last_trade_time
        state.pop("open_order_id", None)
        state["last_trade_time"] = last_bar.isoformat()
        save_state(args.state, state)

        # Health summary after each bar
        log.info("[HEALTH] trades=%s turnover_btc=%.8f last_bar=%s", int(state.get("trade_count", 0)), float(state.get("cum_turnover_btc", 0.0)), last_bar.isoformat())

        time.sleep(args.poll_sec)

if __name__ == "__main__":
    main()